
import React, { useContext, useEffect, useState } from 'react';
import Spinner from '@/components/elements/Spinner';
import useFlash from '@/plugins/useFlash';
import { Form, Formik } from 'formik';
import FlashMessageRender from '@/components/FlashMessageRender';
import McModsRow from '@/components/server/mcmods/McModsRow';
import tw from 'twin.macro';
import Field from '@/components/elements/Field';
import { object, string } from 'yup';
import getMinecraftMcMods, { Context as ServerMcModsContext } from '@/api/swr/getMinecraftMcMods';
import ServerContentBlock from '@/components/elements/ServerContentBlock';
import Pagination from '@/components/elements/PaginationMcMods';

interface Values {
    search: string;
}

const McModsContainer = () => {
    const { page, setPage, searchFilter, setSearchFilter } = useContext(ServerMcModsContext);
    const { clearFlashes, clearAndAddHttpError } = useFlash();
    const { data: minecraftMcMods, error, isValidating } = getMinecraftMcMods();

    const submit = ({ search }: Values) => {
        clearFlashes('minecraftMcMods');
        setSearchFilter(search);
    };

    useEffect(() => {
        if (!error) {
            clearFlashes('minecraftMcMods');

            return;
        }

        clearAndAddHttpError({ error, key: 'minecraftMcModss' });
    }, [ error ]);

    if (!minecraftMcMods || (error && isValidating)) {
        return <Spinner size={'large'} centered/>;
    }
    console.log(minecraftMcMods);
    return (
        <ServerContentBlock title={'Minecraft Mods'} css={tw`bg-transparent`}>
            <FlashMessageRender byKey={'minecraftMcModss'} css={tw`mb-4`}/>
            <Formik
                onSubmit={submit}
                initialValues={{
                    search: searchFilter,
                }}
                validationSchema={object().shape({
                    search: string().optional().min(1),
                })}
            >
                <Form css={tw`mb-3`}>
                    <Field
                        id={'search'}
                        name={'search'}
                        label={'Rechercher'}
                        type={'text'}
                    />
                </Form>
            </Formik>
            <Pagination data={minecraftMcMods} onPageSelect={setPage}>
                {({ items }) => (
                    !items.length ?
                        <p css={tw`text-center text-sm text-neutral-300`}>
                            {page > 1 ?
                                'On dirait que nous n\'avons plus de mods CurseForge à vous montrer, essayez de revenir en arrière.'
                                :
                                'Il semble qu\'il n\'y ait pas de mods CurseForge correspondant aux critères de recherche.'
                            }
                        </p>
                        :
                        items.map((minecraftMcMods, index) => <McModsRow
                            key={minecraftMcMods.id}
                            minecraftMcMods={minecraftMcMods}
                            css={index > 0 ? tw`mt-2` : undefined}
                        />)
                )}
            </Pagination>
        </ServerContentBlock>
    );
};

export default () => {
    const [ page, setPage ] = useState<number>(1);
    const [ searchFilter, setSearchFilter ] = useState<string>('');

    return (
        <ServerMcModsContext.Provider value={{ page, setPage, searchFilter, setSearchFilter }}>
            <McModsContainer/>
        </ServerMcModsContext.Provider>
    );
};
